<?php $__env->startSection('content'); ?>


    <h2 class="titulo-section"><?php echo e($tema->name); ?></h2>

    <!--PUBLICACIONES -->

    <div class="w-dyn-list">
      <div role="list" class="blog-list w-dyn-items">
        <?php $__currentLoopData = $tema->blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div role="listitem" class="w-dyn-item">
          <div class="cardcontainer">
            <a href="<?php echo e(route('blogs.show', $blog->id)); ?>" class="blogcard w-inline-block">
              <img src="<?php echo e(asset('b_images/' . $blog->image_path)); ?>" loading="lazy" alt="" class="blogimage">
              <div class="bloginfocard">
                <h4 class="blogcardheader"><?php echo e($blog->name); ?></h4>
                <span class="badge bg-info text-white" style="font-weight: 600"><?php echo e($tema->name); ?></span>
              </div>
            </a>
          </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </div> 

    <!--TEMAS -->

    <div class="temasdiv mt-5">
      <div class="w-dyn-list">
        <div role="list" class="temaslist w-dyn-items w-row">
          <?php $__currentLoopData = $temas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tema): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div role="listitem" class="collection-item w-dyn-item w-col w-col-4">
          <?php if(auth()->guard()->guest()): ?>
            <a href="<?php echo e(route('temas.show', $tema->id)); ?>" class="coolbutton5 existentes w-inline-block" type="button">                       
              <div class="text-block-6"><?php echo e($tema->name); ?></div>
            </a>
              <?php else: ?>
            <a class="coolbutton5 existentes w-inline-block" type="button" data-bs-toggle="modal" data-bs-target="#editarTarea_<?php echo e($tema->id); ?>">                       
              <div class="text-block-6"><?php echo e($tema->name); ?></div>
            </a>
          <?php endif; ?>
          </div>
           <!-- Modal -->
            <div class="modal fade" id="editarTarea_<?php echo e($tema->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog">
                <div class="modal-content">
                  <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Edición de tema</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                  </div>
                  <form action="<?php echo e(route('temas.update', $tema->id)); ?>" method="POST">
                  <div class="modal-body">
                    <!--campo de protección de formulario-->
                    <?php echo e(csrf_field()); ?>

                    <?php echo e(method_field('PUT')); ?>

                    <!--Campos de formulario-->    
                    <label for="">Nombre del tema</label>
                    <input class="form-control" type="text" placeholder="Nombre del tema" name="name" value="<?php echo e($tema->name); ?>">
                  </div>
                  <div class="modal-footer">
                    <form action="<?php echo e(route('temas.destroy', $tema->id)); ?>" method="POST">
                        <?php echo e(csrf_field()); ?>

                        <?php echo e(method_field('DELETE')); ?> 
                          <button type="submit" class="btn btn-outline-danger">Eliminar</button>
                    </form> 
                      <button type="submit" class="btn btn-outline-success">Guardar cambios</button>
                      <a href="<?php echo e(route('temas.show', $tema->id)); ?>" type="button" class="btn btn-outline-info">Ver tema</a>
                  </div>
                    </form>
                </div>
              </div>
            </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
      </div>
      <div class="w-embed">
        <style>
        .coolbutton5:hover {
	box-shadow: 0 0 5px #97f9af,
							0 0 25px #97f9af,
              0 0 50px #97f9af,
              0 0 200px #97f9af;
          }
        </style>
      </div>
      <a href="<?php echo e(route('blog.index')); ?>" type="button" class="coolbutton5 w-inline-block mt-1">
        <div class="text-block-7">Ver todas las publicaciones</div>
      </a>
    </div>
  </div>
  </div>
  </div>



<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.blog', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/web-droctavio/resources/views/temas/show.blade.php ENDPATH**/ ?>