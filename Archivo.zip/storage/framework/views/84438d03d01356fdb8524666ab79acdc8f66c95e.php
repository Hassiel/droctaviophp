<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <h2 class="h2hero"><strong  class="bold-text">Hola <?php echo e(Auth::user()->name); ?></strong></h2>
            <div class="card">
                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                        <div class="card-body">
                            <p class="card-text">Crea nuevas publicaciones y agrega nuevos productos a la lista.</p>
                            <a href="<?php echo e(route('blogs.index')); ?>" class="card-link">Publicaciones</a>
                            <a href="<?php echo e(route('productos.index')); ?>" class="card-link">Productos</a>
                        </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/web-droctavio/resources/views/home.blade.php ENDPATH**/ ?>