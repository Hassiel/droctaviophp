    
<?php $__env->startSection('content'); ?> 
    <h2 class="titulo-section">Blog del Dr. Octavio</h2>

    <!--PUBLICACIONES -->

    <div class="w-dyn-list">
      <div role="list" class="blog-list w-dyn-items">
        <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div role="listitem" class="w-dyn-item">
          <div class="cardcontainer">
            <a href="<?php echo e(route('blog.show', $blog->id)); ?>" class="blogcard w-inline-block">
              <img src="<?php echo e(asset('b_images/' . $blog->image_path)); ?>" loading="lazy" alt="" class="blogimage">
              <div class="bloginfocard">
                <h4 class="blogcardheader"><?php echo e($blog->name); ?></h4>
                <span class="badge bg-info text-white" style="font-weight: 600"><?php echo e($blog->topic_id); ?></span>
              </div>
            </a>
            <?php if(auth()->guard()->guest()): ?>
                <?php else: ?>
                <div class="cardbuttoncontainer">
              <a href="<?php echo e(route('blogs.edit', $blog->id)); ?>" class="cardbutton _1 w-inline-block">
                <img src="images/draw.png" loading="lazy" width="20" alt="" class="cardbuttonimage"></a>
               <form action="<?php echo e(route('blogs.destroy', $blog->id)); ?>" method="POST">
            <?php echo e(csrf_field()); ?>

            <?php echo e(method_field('DELETE')); ?> 
              <button type="submit" class="cardbutton _2 w-inline-block btn-outline-danger" >
                <img src="images/delete.png" loading="lazy" width="20" alt="" class="cardbuttonimage"></a>
                </form> 
            </div>
            <?php endif; ?>
          </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </div>
    <?php echo e($blogs->links()); ?>

    <?php if(auth()->guard()->guest()): ?>
        <?php else: ?>
      <div class="addnewbutton">
      <a data-w-id="e5c33930-a9d6-c5f2-53ae-f8bf50989d46" href="<?php echo e(route('blogs.create')); ?>" class="blogcard newpost w-inline-block">
        <div class="bloginfocard newpost">
          <div data-w-id="875cdc08-dfa6-61ba-aa8c-fa520186febf" data-animation-type="lottie" data-src="documents/add-post.json" data-loop="0" data-direction="1" data-autoplay="0" data-is-ix2-target="1" data-renderer="svg" data-default-duration="3" data-duration="0" data-ix2-initial-state="0"></div>
          <h4 class="blogcardheader">Nueva publicación</h4>
        </div>
      </a>
    </div>
    <?php endif; ?>

     <!--TEMAS -->

    <div class="temasdiv mt-5">
      <div class="w-dyn-list">
        <div role="list" class="temaslist w-dyn-items w-row">
          <?php $__currentLoopData = $temas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tema): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div role="listitem" class="collection-item w-dyn-item w-col w-col-4">
          <?php if(auth()->guard()->guest()): ?>
            <a href="<?php echo e(route('tema.show', $tema->id)); ?>" class="coolbutton5 existentes w-inline-block" type="button">                       
              <div class="text-block-6"><?php echo e($tema->name); ?></div>
            </a>
              <?php else: ?>
            <a class="coolbutton5 existentes w-inline-block" type="button" data-bs-toggle="modal" data-bs-target="#editarTarea_<?php echo e($tema->id); ?>">                       
              <div class="text-block-6"><?php echo e($tema->name); ?></div>
            </a>
          <?php endif; ?>
          </div>
           <!-- Modal -->
            <div class="modal fade" id="editarTarea_<?php echo e($tema->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog">
                <div class="modal-content">
                  <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel"><?php echo e($tema->name); ?></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                  </div>
                  <div class="modal-footer">
                    <form action="<?php echo e(route('temas.destroy', $tema->id)); ?>" method="POST">
                        <?php echo e(csrf_field()); ?>

                        <?php echo e(method_field('DELETE')); ?> 
                          <button type="submit" class="btn btn-outline-danger">Eliminar</button>
                    </form> 
                      <a href="<?php echo e(route('temas.show', $tema->id)); ?>" type="button" class="btn btn-outline-info">Ver tema</a>
                </div>
              </div>
            </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
      </div>
      <div class="w-embed">
        <style>
        .coolbutton5:hover {
	box-shadow: 0 0 5px #97f9af,
							0 0 25px #97f9af,
              0 0 50px #97f9af,
              0 0 200px #97f9af;
          }
        </style>
      </div>
      <?php if(auth()->guard()->guest()): ?>
          <?php else: ?>
          <a type="button" class="coolbutton5 w-inline-block mt-1" data-bs-toggle="modal" data-bs-target="#exampleModal">
        <div class="text-block-7">Crear nuevo tema</div>
      </a>
      <?php endif; ?>
    </div>
  </div>
  </div>
  </div>
  <!-- Modal -->
      <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="modalTarea">Crear nuevo tema</h5>
              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="<?php echo e(route('temas.store')); ?>" method="POST">
                  <div class="modal-body">
                      <!--campo de protección de formulario-->
                  <?php echo e(csrf_field()); ?>

                  <!--Campos de formulario-->
                  <div class="form-group mb-3">
                      <label for="">Nombre del tema</label>
                      <input class="form-control"type="text" placeholder="Nombre del tema" name="name">
                  </div>          
                  </div>
                  <div class="modal-footer">
                      <button type="button" class="btn btn-outline-danger" data-bs-dismiss="modal">Cerrar</button>
                      <button type="submit" class="btn btn-outline-success">Guardar tema</button>
                  </div>
              </form>
          </div>
        </div>
      </div>
  <?php $__env->stopSection(); ?>   
  
<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/web-droctavio/resources/views/blog/index.blade.php ENDPATH**/ ?>